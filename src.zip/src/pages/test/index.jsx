import React, { Component } from 'react';

class Test extends Component{
    render(){
        return(
            <div>
                123
            </div>
        )
    }
}