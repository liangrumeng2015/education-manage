import React from 'react'
import styles from './index.scss'
const Foot = () =>{
    return(
        <div className={styles.footer}>
            Ant Design ©2018 Created by Ant UED
        </div>
    )
}
export default Foot;