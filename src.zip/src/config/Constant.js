/**
 * 配置项目中的一些常量的地方
 */
export const MANAGE_NAME = 'education管理后台'    // 管理后台的名称
export const LOGO = 'https://www.baidu.com/favicon.ico'  